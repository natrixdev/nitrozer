import random, string

import webbrowser


print('''

███╗░░██╗██╗████████╗██████╗░░█████╗░███████╗███████╗██████╗░
████╗░██║██║╚══██╔══╝██╔══██╗██╔══██╗╚════██║██╔════╝██╔══██╗
██╔██╗██║██║░░░██║░░░██████╔╝██║░░██║░░███╔═╝█████╗░░██████╔╝
██║╚████║██║░░░██║░░░██╔══██╗██║░░██║██╔══╝░░██╔══╝░░██╔══██╗
██║░╚███║██║░░░██║░░░██║░░██║╚█████╔╝███████╗███████╗██║░░██║
╚═╝░░╚══╝╚═╝░░░╚═╝░░░╚═╝░░╚═╝░╚════╝░╚══════╝╚══════╝╚═╝░░╚═╝
''')

print('''
BEST NITRO GENERATOR\n
''')
print('''
BY NATRIX\n
''')
input('''
PRESS *ENTER* TO RUN THE PROGRAM\n
''')


num = input('How Many Codes to Generate: ')
charSet = f"{string.ascii_uppercase}{string.digits}{string.ascii_lowercase}"
bigStr = ""

with open("Nitro Codes.txt","w", encoding='utf-8') as file:

    print(f'Wait, Generating for you!')

    for i in range(int(num)):
        bigStr += f'https://discord.gift/{"".join(random.choices(charSet, k = 16))}\n'
        if i % 100_000 == 0:
            file.write(f'{bigStr}\n')
            bigStr = ""


    print(f'Successfully, generated they are in Nitro Codes.txt"')
    input("Press Enter To Close!")